package com.blazify.music.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.blazify.innertube.models.AlbumItem
import com.blazify.innertube.models.Artist
import com.blazify.innertube.models.looksLikeArtistName
import com.blazify.innertube.models.ArtistItem
import com.blazify.innertube.models.EpisodeItem
import com.blazify.innertube.models.PlaylistItem
import com.blazify.innertube.models.PodcastItem
import com.blazify.innertube.models.SongItem
import com.blazify.innertube.models.YTItem

@Entity(tableName = "speed_dial_item")
data class SpeedDialItem(
    @PrimaryKey val id: String,
    val secondaryId: String? = null,
    val title: String,
    val subtitle: String? = null,
    val subtitleIds: String? = null,
    val thumbnailUrl: String? = null,
    val type: String, // "SONG", "ALBUM", "ARTIST", "PLAYLIST", "LOCAL_PLAYLIST"
    val explicit: Boolean = false,
    val createDate: Long = System.currentTimeMillis(),
    val albumId: String? = null,
    val albumName: String? = null
) {
    /**
     * The artists saved with this tile, rebuilt from their names and ids. Tiles pinned before
     * artist names were read properly saved the separators too (", ", " & "), so anything
     * that is not a name is left out here instead of showing as ", , &" beside the song.
     */
    private fun savedArtists(): List<Artist>? {
        val ids = subtitleIds?.split(", ")
        return subtitle?.split(", ")
            ?.mapIndexed { index, name -> Artist(name = name, id = ids?.getOrNull(index)?.ifEmpty { null }) }
            // A YouTube artist id ("UC...") vouches for a name; ids the app made up ("LA...") do not.
            ?.filter { it.id?.startsWith("UC") == true || looksLikeArtistName(it.name) }
    }

    fun toYTItem(): YTItem {
        return when (type) {
            "SONG" -> SongItem(
                id = id,
                title = title,
                artists = savedArtists() ?: emptyList(),
                album = if (albumId != null && albumName != null) com.blazify.innertube.models.Album(name = albumName, id = albumId) else null,
                thumbnail = thumbnailUrl ?: "",
                explicit = explicit
            )
            "ALBUM" -> AlbumItem(
                browseId = id,
                playlistId = secondaryId ?: "",
                title = title,
                artists = savedArtists(),
                thumbnail = thumbnailUrl ?: "",
                explicit = explicit
            )
            "ARTIST" -> ArtistItem(
                id = id,
                title = title,
                thumbnail = thumbnailUrl,
                shuffleEndpoint = null,
                radioEndpoint = null
            )
            "PLAYLIST", "LOCAL_PLAYLIST" -> PlaylistItem(
                id = id,
                title = title,
                author = subtitle?.let { name ->
                    Artist(name = name, id = subtitleIds)
                },
                songCountText = null,
                thumbnail = thumbnailUrl,
                playEndpoint = null,
                shuffleEndpoint = null,
                radioEndpoint = null
            )
            else -> throw IllegalArgumentException("Unknown type: $type")
        }
    }

    companion object {
        fun fromYTItem(item: YTItem): SpeedDialItem {
            return when (item) {
                is SongItem -> SpeedDialItem(
                    id = item.id,
                    title = item.title,
                    subtitle = item.artists.joinToString(", ") { it.name },
                    subtitleIds = item.artists.joinToString(", ") { it.id ?: "" },
                    thumbnailUrl = item.thumbnail,
                    type = "SONG",
                    explicit = item.explicit,
                    albumId = item.album?.id,
                    albumName = item.album?.name
                )
                is AlbumItem -> SpeedDialItem(
                    id = item.browseId,
                    secondaryId = item.playlistId,
                    title = item.title,
                    subtitle = item.artists?.joinToString(", ") { it.name },
                    subtitleIds = item.artists?.joinToString(", ") { it.id ?: "" },
                    thumbnailUrl = item.thumbnail,
                    type = "ALBUM",
                    explicit = item.explicit
                )
                is ArtistItem -> SpeedDialItem(
                    id = item.id,
                    title = item.title,
                    thumbnailUrl = item.thumbnail,
                    type = "ARTIST"
                )
                is PlaylistItem -> SpeedDialItem(
                    id = item.id,
                    title = item.title,
                    subtitle = item.author?.name,
                    subtitleIds = item.author?.id,
                    thumbnailUrl = item.thumbnail,
                    type = "PLAYLIST"
                )
                is PodcastItem -> SpeedDialItem(
                    id = item.id,
                    title = item.title,
                    subtitle = item.author?.name,
                    subtitleIds = item.author?.id,
                    thumbnailUrl = item.thumbnail,
                    type = "PLAYLIST"
                )
                is EpisodeItem -> SpeedDialItem(
                    id = item.id,
                    title = item.title,
                    subtitle = item.author?.name,
                    subtitleIds = item.author?.id,
                    thumbnailUrl = item.thumbnail,
                    type = "SONG",
                    explicit = item.explicit,
                    albumId = item.podcast?.id,
                    albumName = item.podcast?.name
                )
            }
        }
    }
}
